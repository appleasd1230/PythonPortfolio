﻿namespace FlexiCapture12_WebService_SampleCode
{
    /// <summary>
    /// Простейшая реализация калькулятора crc 32.
    /// </summary>
    internal class Crc32
    {
        /// <summary>
        /// Таблица crc
        /// </summary>
        private readonly uint[] _crcTable;

        /// <summary>
        /// Текущее значение crc
        /// </summary>
        private uint _crc;

        /// <summary>
        /// Создаёт новый объект калькулятора crc32
        /// </summary>
        public Crc32()
        {
            _crcTable = new uint[256];
            for (uint i = 0; i < 256; i++)
            {
                var crc = i;
                for (var j = 0; j < 8; j++)
                    crc = (crc & 1) != 0 ? (crc >> 1) ^ 0xedb88320 : crc >> 1;

                _crcTable[i] = crc;
            };
            _crc = 0xffffffff;
        }

        /// <summary>
        /// Обновляет значение crc на основании нового буфера данных
        /// </summary>
        /// <param name="buffer">Буффер просчитываемых данных</param>
        /// <param name="offset">Смещение в буфере</param>
        /// <param name="count">Количество байт</param>
        /// <returns>Значение crc32 после обработки буфера</returns>
        public uint Next(byte[] buffer, int offset, int count)
        {
            for (var i = 0; i < count; i++)
            {
                _crc = _crcTable[(_crc ^ buffer[i + offset]) & 0xff] ^ (_crc >> 8);
            }
            return _crc ^ 0xffffffff;
        }
    }
}