﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Globalization;

namespace FlexiCapture12_WebService_SampleCode
{

    public partial class Form1 : Form
    {
        FlexiCapture.FlexiCaptureWebServiceSoapClient service;
        int userId = -1;
        int sessionId = -1;
        int ProjectId = -1;
        int BatchTypeId = -1;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            service = new FlexiCapture.FlexiCaptureWebServiceSoapClient();
            service.ClientCredentials.UserName.UserName = textBox1.Text;
            service.ClientCredentials.UserName.Password = textBox2.Text;

            var username = service.GetCurrentUserIdentity();
            userId = service.FindUser(username.Name);
            if (userId <= 0) throw new Exception("Current user not found");

            // Session parameters
            const int roleType = 11; //The operator role on the user's station
            const int stationType = 10; //The user’s station
            // Open a new processing session
            sessionId = service.OpenSession(roleType, stationType);
            if (sessionId <= 0) throw new Exception("Couldn’t open the session");

            textBox5.Enabled = true;
            button6.Enabled = true;

            textBox3.Text = sessionId.ToString();

            var Projects = service.GetProjects();
            foreach (var project in Projects)
            {
                listBox1.Items.Add(project.Name);
            }

        }


        private void Form1_Load(object sender, EventArgs e)
        {
            // 在 Load 事件撰寫讀取設定程式碼
            textBox1.Text = FlexiCapture12_WebService_SampleCode.Properties.Settings.Default.UsernameSetting;
            textBox2.Text = FlexiCapture12_WebService_SampleCode.Properties.Settings.Default.PasswordSetting;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            // 在 FormClosing 事件撰寫儲存設定程式碼
            FlexiCapture12_WebService_SampleCode.Properties.Settings.Default.UsernameSetting = textBox1.Text;
            FlexiCapture12_WebService_SampleCode.Properties.Settings.Default.PasswordSetting = textBox2.Text;
            FlexiCapture12_WebService_SampleCode.Properties.Settings.Default.Save();

            if (sessionId != -1)
            {
                service.CloseSession(sessionId);
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ProjectName = listBox1.SelectedItem.ToString();
            ProjectId = service.OpenProject(sessionId, ProjectName);
            if (ProjectId <= 0) throw new Exception("Couldn’t open the project");

            listBox2.Items.Clear();

            var BatchTypes = service.GetBatchTypes(ProjectId);
            if (BatchTypes != null)
            {
                foreach (var BatchType in BatchTypes)
                {
                    listBox2.Items.Add(BatchType.Name);
                }
            }
            else
            {
                BatchTypeId = -1;
            }

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox2.SelectedItem != null)
            {
                string SelectedBatchType = listBox2.SelectedItem.ToString();
                var BatchTypes = service.GetBatchTypes(ProjectId);
                foreach (var BatchType in BatchTypes)
                {
                    if (BatchType.Name == SelectedBatchType)
                    {
                        BatchTypeId = BatchType.Id;
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Multiselect = true;//該值確定是否可以選擇多個檔案
            dialog.Title = "請選擇檔案";
            dialog.Filter = "影像檔案(*.jpg;*.jpeg;*.pdf;*.png; *.tif)|*.jpg;*.jpeg;*.pdf;*.png; *.tif";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                foreach (var FileName in dialog.FileNames)
                {
                    listBox3.Items.Add(FileName);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            for (int i = this.listBox3.Items.Count - 1; i >= 0; i--)
            {
                listBox3.Items.Remove(listBox3.SelectedItem);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (userId == -1)
            {
                MessageBox.Show("尚未登入");
                return;
            }
            else if (sessionId == -1)
            {
                MessageBox.Show("尚未建立連線");
                return;
            }
            else if (ProjectId == -1)
            {
                MessageBox.Show("尚未選擇專案");
                return;
            }
            else if (listBox3.Items.Count == 0)
            {
                MessageBox.Show("尚未選擇檔案");
                return;
            }

            var batch = new FlexiCapture.Batch { Name = "API Batch_" + textBox1.Text + "_" + DateTime.Now.ToString("HH.mm.ss") };
            if (BatchTypeId != -1)
            {
                batch.BatchTypeId = BatchTypeId;
            }
            var batchId = service.AddNewBatch(sessionId, ProjectId, batch, -1);
            if (batchId <= 0) throw new Exception("Couldn’t create the batch");

            foreach (var Item in listBox3.Items)
            {
                AddImageToBatch(service, sessionId, ProjectId, batchId, @Item.ToString() );
            }

            // Start processing the batch
            service.ProcessBatch(sessionId, batchId);
            MessageBox.Show("上傳檔案成功! (BatchID: " + batchId.ToString() + ")");

            string AppendText = "Batch ID: " + batchId.ToString() + "\r\n";
            foreach (var Item in listBox3.Items)
            {
                AppendText += Path.GetFileName(Item.ToString()) + "\r\n";
            }
            AppendText += "-----------------------------------------\r\n";
            textBox4.AppendText(AppendText);

            textBox5.Text = batchId.ToString();
        }

        private static void AddImageToBatch(FlexiCapture.FlexiCaptureWebServiceSoapClient service, int sessionId, int projectId, int batchId, string filename)
        {
            service.OpenBatch(sessionId, batchId);
            try
            {
                var doc = new FlexiCapture.Document { BatchId = batchId };
                var file = new FlexiCapture.File { Name = filename };
                var documentId = service.AddNewDocument(sessionId, doc, file, false, -1);
                UploadFile(service, sessionId, projectId, batchId, documentId, filename).Wait();

            }
            finally
            {
                service.CloseBatch(sessionId, batchId);
            }
        }

        private static async Task UploadFile(FlexiCapture.FlexiCaptureWebServiceSoapClient service, int sessionId, int projectId,
            int batchId, int documentId, string filename)
        {
            const int objectType = 0;
            var crc = new Crc32();
            using (var fs = File.OpenRead(filename))
            {
                // Uploading portions of 1 MB each
                var buffer = new byte[0x100000];

                var readed = fs.Read(buffer, 0, buffer.Length);
                var checksum = crc.Next(buffer, 0, readed);
                if (readed < buffer.Length)
                {
                    // Uploading smaller files in their entirety
                    var resp = await FileRequest(service, "Save", objectType, sessionId, projectId, batchId, 0, documentId, 0, filename, 0,
                        new ByteArrayContent(buffer, 0, readed)).ConfigureAwait(false);
                    if (resp.StatusCode != HttpStatusCode.OK) throw new Exception("Server error");
                }
                else
                {
                    var offset = 0;
                    while (readed > 0)
                    {
                        var action = offset == 0 ? "BeginSaveChunked" : "Append";
                        await FileRequest(service, action, objectType, sessionId, projectId, batchId, 0, documentId, 0, filename,
                            offset, new ByteArrayContent(buffer, 0, readed)).ConfigureAwait(false);
                        offset += readed;
                        readed = fs.Read(buffer, 0, buffer.Length);
                        checksum = crc.Next(buffer, 0, readed);
                    }
                    var resp = await FileRequest(service, "Commit", objectType, sessionId, projectId, batchId, 0, documentId, 0, filename);
                    if (resp.StatusCode != HttpStatusCode.OK) throw new Exception("Server error");
                }
                var response = await FileRequest(service, "Checksum", objectType, sessionId, projectId, batchId, 0, documentId, 0, filename);
                var text = await response.Content.ReadAsStringAsync();
                if (uint.Parse(text, NumberStyles.HexNumber) != checksum)
                {
                    throw new Exception("An error occurred when uploading the file");
                }
            }
        }


        private static async Task<HttpResponseMessage> FileRequest(FlexiCapture.FlexiCaptureWebServiceSoapClient service, string action,
            int objectType, int sessionId, int projectId, int batchId, int parentId, int objectId, int version, string streamName)
        {
            var creds = CredentialCache.DefaultNetworkCredentials;
            if (!string.IsNullOrEmpty(service.ClientCredentials.UserName.UserName))
                creds = new NetworkCredential(service.ClientCredentials.UserName.UserName, service.ClientCredentials.UserName.Password);
            using (var handler = new HttpClientHandler { Credentials = creds })
            using (var client = new HttpClient(handler))
            {
                var uri = service.Endpoint.Address.Uri;
                var content = new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    {"Action", action},
                    {"objectType", objectType.ToString()},
                    {"sessionId", sessionId.ToString()},
                    {"projectId", projectId.ToString()},
                    {"batchId", batchId.ToString()},
                    {"parentId", parentId.ToString()},
                    {"objectId", objectId.ToString()},
                    {"version", version.ToString()},
                    {"streamName", streamName},
                });
                return await client.PostAsync(uri.OriginalString.Replace("/API/v1/Soap", "/FileService/v1"), content);
            }
        }


        private static async Task<HttpResponseMessage> FileRequest(FlexiCapture.FlexiCaptureWebServiceSoapClient service, string action,
            int objectType, int sessionId, int projectId, int batchId, int parentId, int objectId, int version, string streamName, int offset, HttpContent file)
        {
            var creds = CredentialCache.DefaultNetworkCredentials;
            if (!string.IsNullOrEmpty(service.ClientCredentials.UserName.UserName))
                creds = new NetworkCredential(service.ClientCredentials.UserName.UserName, service.ClientCredentials.UserName.Password);
            using (var handler = new HttpClientHandler { Credentials = creds })
            using (var client = new HttpClient(handler))
            {
                var uri = service.Endpoint.Address.Uri;
                var content = new MultipartFormDataContent
                {
                    {new StringContent(action), "Action"},
                    {new StringContent(objectType.ToString()), "objectType"},
                    {new StringContent(sessionId.ToString()), "sessionId"},
                    {new StringContent(projectId.ToString()), "projectId"},
                    {new StringContent(batchId.ToString()), "batchId"},
                    {new StringContent(parentId.ToString()), "parentId"},
                    {new StringContent(objectId.ToString()), "objectId"},
                    {new StringContent(version.ToString()), "version"},
                    {new StringContent(Convert.ToBase64String(Encoding.Unicode.GetBytes(streamName))), "streamName"},
                };
                if (offset > 0)
                {
                    content.Add(new StringContent(offset.ToString()), "offset");
                }
                content.Add(file, "blob", "data.txt");
                return await client.PostAsync(uri.OriginalString.Replace("/API/v1/Soap", "/FileService/v1"), content).ConfigureAwait(false);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox3.Items.Clear();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int BatchID_Query;
            if (!Int32.TryParse(textBox5.Text, out BatchID_Query))
            {
                MessageBox.Show("請輸入Batch ID", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var percentCompleted = service.GetBatchPercentCompleted(BatchID_Query);
            var BatchInfo = service.GetBatch(BatchID_Query);

            if (BatchInfo.Id == 0)
            {
                MessageBox.Show("查無此Batch ID", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            
            if (percentCompleted != 100)
            {
                MessageBox.Show("尚未有任何輸出檔案, 任務進度:" + percentCompleted + "%", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var documents = service.GetDocuments(sessionId, BatchID_Query);
            if (documents == null)
            {
                MessageBox.Show("無法取得documents", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            textBox4.AppendText("Batch ID: " + BatchID_Query.ToString() + " 檢測到" + BatchInfo.ExportedDocumentsCount + "組文件可輸出\r\n");

            if (BatchInfo.ExportedDocumentsCount == 0)
            {
                return;
            }
            
            using (var fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                {
                    int ExportedFileCounts = 0;
                    foreach (var document in documents)
                    {
                        if (document.Id == 0) continue;

                        var attachedFilesName = service.GetDocumentResultsList(sessionId, BatchID_Query, document.Id);
                        if (attachedFilesName != null)
                        {
                            foreach (var attachedFileName in attachedFilesName)
                            {
                                var attachedFile = service.LoadDocumentResult(sessionId, BatchID_Query, document.Id, attachedFileName);
                                if (attachedFile.Bytes == null) continue;

                                try
                                {
                                    string RootPath = fbd.SelectedPath;
                                    string FileName = attachedFileName.Replace('\\','_');
                                    string SavePath = Path.Combine(RootPath, FileName);
                                    using (var fs = new FileStream(SavePath, FileMode.Create, FileAccess.Write))
                                    {
                                        fs.Write(attachedFile.Bytes, 0, (attachedFile.Bytes.Length));
                                        textBox4.AppendText("輸出檔案: " + attachedFileName  + "\r\n");
                                        ExportedFileCounts++;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show("Exception caught in process:" + ex.Message);
                                    return;
                                }
                            }
                        }
                    }
                    textBox4.AppendText("共輸出" + ExportedFileCounts + "個檔案\r\n");
                    textBox4.AppendText("-----------------------------------------\r\n");
                }
            }
        }

    }
}
